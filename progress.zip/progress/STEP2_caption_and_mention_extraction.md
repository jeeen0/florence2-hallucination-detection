# Step 2 — Caption 생성 + COCO80 mention 추출

> **목표**: COCO val2017 50장에 대해 Florence-2-base-ft `<CAPTION>`을 생성하고, COCO80 어휘 + synonym map으로 객체 mention을 추출한다.

## 1. 추가된 코드

| 파일 | 역할 |
| --- | --- |
| `code/data_utils.py` | COCO val2017 이미지 다운로더 (annotations 없이 ID만으로) |
| `code/modules/caption.py` | `Florence2Runner` 위의 얇은 caption 헬퍼 |
| `code/modules/extract.py` | COCO80 vocabulary + synonym map + 추출 알고리즘 |
| `code/run_step2.py` | Step 2 오케스트레이터 |

## 2. 데이터 수집

CANDIDATE_IDS 100개에서 시드(42)로 셔플 후 앞쪽부터 50장 시도 → 50/50 모두 다운로드 성공.

> 처음에는 `annotations_trainval2017.zip` (241MB) 전체를 받을지 고민했으나 Step 2에서는 GT가 불필요해서 ID 하드코딩 + 직접 다운로드 방식 채택. Step 4에서야 annotations 받음.

## 3. 추출 알고리즘 (extract.py)

1. **정규화**: 소문자, 영문/숫자/공백/하이픈 외 제거.
2. **lookup 테이블**: 80개 canonical × 각 canonical의 synonym 들을 `(surface, canonical)` 쌍으로 펼친 뒤 길이 내림차순 정렬.
3. **whole-word 매칭**: `(?<!\w)<surface>(?!\w)` 패턴으로 검색. 다중-단어 표현(`dining table`, `fire hydrant`)이 단일 단어보다 먼저 매칭되도록 정렬.
4. **non-overlap**: 이미 매칭된 구간과 겹치는 후속 매칭은 버림 → "dining table" 매칭 후 그 안의 "table"은 무시.

### Synonym map 주요 매핑
- `man/woman/boy/girl/people/kid/...` → `person`
- `bike/bikes/bicycles` → `bicycle`
- `motorbike/motorcycles` → `motorcycle`
- `plane/aeroplane/jet/aircraft` → `airplane`
- `sofa/sofas/couches` → `couch`
- `table/tables` → `dining table`  ← **주의**: 실제 식탁이 아닌 테이블도 잡힘 (Step 4에서 FN 발생)
- `tv/television/monitor` → `tv`
- `phone/cellphone/mobile/smartphone` → `cell phone`
- `bat/bats` → `baseball bat`
- `baseball/soccer ball/basketball/football/tennis ball` → `sports ball`  ← **주의**: Florence-2 OD가 `sports ball`로 라벨링하지 않으면 Step 3에서 unsupported 처리됨

## 4. 실행

```powershell
python code/run_step2.py --n 50
```

* 처음 30장은 1~2초/장 (이미지 다운로드+caption 생성).
* 모델은 Step 1에서 캐시된 가중치 재사용.

## 5. 결과

- **50/50 이미지** 처리 성공.
- **73개 mention** 추출.
- **0-mention 3건**: `tripod with camera`, `plate of food with chicken/rice/vegetables`, `white plate topped with rice and vegetables` — 모두 COCO80에 없는 객체 위주 → 정상 동작.

### 출력 파일
| 파일 | 컬럼 |
| --- | --- |
| `outputs/captions/base_caption_50.csv` | image_id, prompt, caption, canonical_objects |
| `outputs/captions/base_extracted_objects.csv` | image_id, surface, canonical, start, end |

### 샘플 caption + 추출 결과
```
12280  "A man walking through an airport with a suitcase."  → person, suitcase
6012   "A bowl of bananas and apples on a wooden table."    → banana, apple, bowl
4495   "A living room with a couch, chair, and tv."          → couch, chair, tv
1296   "A woman is taking a picture with her cell phone."   → person, cell phone
```

## 6. 알게 된 점 (Step 3+ 입력)

1. Florence-2 `<CAPTION>`은 짧고 함축적. `<DETAILED_CAPTION>`을 쓰면 mention 수가 더 늘 것으로 예상. 본 Step에서는 짧은 caption만 사용.
2. **테이블 처리의 모호성**: caption은 "table"이라고 하지만 GT 카테고리는 "dining table"만 존재. 따라서 일반 책상/책상도 `dining table` canonical로 매핑되어 GT 비교 시 FN 발생.
3. **Sports ball 어휘**: caption은 종목 이름(`baseball`, `soccer ball`, `basketball`)을 쓰지만 Florence-2 OD는 그런 라벨로 부르지 않는 경우 많음 → Step 3에서 unsupported로 잡힘.
4. Multi-word phrase 우선 매칭은 안정적으로 동작 (loop sort + occupied 검사).

## 7. 변경된 저장소 상태
- 커밋 `2ff0fd4` Step 2: COCO val2017 fetcher, COCO80 synonym map, caption + mention extraction
