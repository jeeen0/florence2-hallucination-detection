# Step 9 (Phase 4) — Cross-Model Verification (BLIP caption × Florence-2 OD)

> **목표**: self-verification(Florence-2 caption × Florence-2 OD)에서 검증이 못 잡는 hallucination이 *동일 모델의 joint blind spot* 때문인지, 아니면 *OD 자체의 구조적 recall 한계* 때문인지를 cross-model 비교로 가른다.

## 1. 설계

같은 200 images에서:
- **Self**: Florence-2-large-ft caption → Florence-2-large-ft `<OD>` 검증
- **Cross**: BLIP-large(`Salesforce/blip-image-captioning-large`) caption → 동일 Florence-2-large-ft `<OD>` 검증

이미지·OD·매칭 어휘(strict) 동일. 캡션 소스만 다름.

## 2. 막힌 점 / 해결

### 2.1 BLIP-2 OPT-2.7B → VRAM OOM
초기 의도였던 `Salesforce/blip2-opt-2.7b` (fp16 ~7 GB) 는 RTX 3070 8 GB에서 Florence-2 large-ft (~1.5 GB) 와 같이 올리기 빠듯 → OOM 후 garbage-collecting 단계에서 fatal crash.

→ `Salesforce/blip-image-captioning-large` (~1.7 GB fp16) 으로 교체. BLIP base+OPT 결합 대신 *원조 BLIP* captioner. 메모리 안전 + 캡션 품질 충분.

### 2.2 C: 드라이브 풀
실패한 BLIP-2 가중치(4 GB) 가 캐시에 남고 시스템이 31 MB 까지 차 디스크 I/O 에러. blip2-opt-2.7b 캐시 삭제 + 사용자가 다른 파일 정리 → 19 GB 확보 후 재실행 성공.

## 3. 결과

| Setting | Mentions | Baseline Hall% (95%CI) | Verified Hall% (95%CI) | P | R | F1 (95%CI) | TP | FP | FN |
| --- | --: | --: | --: | --: | --: | --: | --: | --: | --: |
| **Self** (F2→F2) | 290 | 2.41% [0.69, 4.48] | 1.05% [0.00, 2.45] | 1.00 | 0.571 | 0.727 [0.250, 1.000] | 4 | 0 | 3 |
| **Cross** (BLIP→F2) | 298 | **4.70%** [2.35, 7.38] | 2.07% [0.69, 3.79] | 1.00 | 0.571 | 0.727 [0.429, 0.909] | 8 | 0 | 6 |

## 4. 핵심 관찰

### 4.1 BLIP가 ~2× 더 hallucinate
- Self baseline 2.41% vs Cross baseline 4.70% → BLIP-large 가 Florence-2-large 보다 caption에서 거짓 객체를 약 2배 자주 언급.
- 두 모델의 hallucination CI 가 *겹치는 부분이 있긴 함* (self [0.69, 4.48] vs cross [2.35, 7.38]) → 통계적으로 결정적이진 않지만 점추정으로는 일관.

### 4.2 Recall이 정확히 동일 (0.571)
- Self: 4/7 = 0.571
- Cross: 8/14 = 0.571

→ caption 소스가 무엇이든 Florence-2 OD가 *놓치는 hallucination 비율은 일정*. 이는 OD recall의 구조적 상한 (POPE recall 83.65% 와 같은 원인 — small/occluded object miss).

### 4.3 Precision은 둘 다 1.0
- 어느 captioner를 써도 over-flag (real object 를 unsupported로) 가 없음.
- 이는 200-img subset 규모 한계도 있음. 500-img CAPTION 실험에서는 self FP=1 발생.

### 4.4 Self-verification 한계 *진단*
- "self verification은 joint blind spot 때문에 약하다" 가설 → 부분적 기각.
- 실제로는 *captioner가 hallucinate를 적게* + *OD가 일정 비율 놓치기* 가 결합한 결과.
- BLIP 같은 더 잘 hallucinate하는 captioner를 써도 OD recall 한계는 동일하게 발현.

### 4.5 절대 catch 수는 cross가 2배
- Self TP=4 vs Cross TP=8 — captioner가 더 hallucinate하면 검증이 절대값으로는 더 많이 잡음.
- 즉 **cross-model verification은 검증 시스템의 한계를 노출시키는 도구**로 가치.

## 5. 페이퍼 활용
- Result 절에 self vs cross 비교 표 추가.
- Discussion에서 self-verification 한계의 *원인 분리* 결과 보고:
  1. captioner의 hallucination rate 자체가 다름 (BLIP > F2)
  2. 그러나 verifier recall은 captioner와 무관 (~0.57 또는 ~0.72, OD 자체 한계)
- "POPE Recall 83.65% ⇔ 본 실험 Verifier Recall 57~72%" 두 수치가 같은 OD recall 결손을 지칭함을 명시.

## 6. 발견된 이슈 / 보완 사항
1. 200 imgs subset CI 가 self 쪽이 매우 넓음 (n_TP=4). 더 큰 cross 실험 (500 imgs) 이 이상적이나 BLIP captioning 속도와 디스크 제약으로 200 채택.
2. BLIP / Florence-2 둘 다 다른 *prompt가 없는* zero-shot caption. prompt engineering 효과는 측정 안 됨.
3. cross가 self보다 mention 수가 약간 많음 (298 vs 290) — BLIP가 더 길게 captions 함. caption 길이 정규화 안 함.

## 7. 산출물
| 파일 | 내용 |
| --- | --- |
| `outputs/cross/blip2_caption.csv` | BLIP captions (200 images) |
| `outputs/cross/self_grounding.csv` | F2→F2 verdict per mention |
| `outputs/cross/cross_grounding.csv` | BLIP→F2 verdict per mention |
| `outputs/metrics/cross_self_metrics.json` | self metric |
| `outputs/metrics/cross_blip_metrics.json` | cross metric |

## 8. 변경된 저장소 상태
- 커밋 (다음) Phase 4 BLIP large fallback + cross-model 결과
