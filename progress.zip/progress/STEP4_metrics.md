# Step 4 — COCO GT 기반 정량 평가

> **목표**: Step 3 검증 결과를 COCO `instances_val2017.json`과 비교하여 4가지 지표(Hall. Rate / CHAIR / Unsupported P·R·F1 / Grounding Acc@0.5) 산출.

## 1. 추가된 코드

| 파일 | 역할 |
| --- | --- |
| `code/coco_gt.py` | `instances_val2017.json` 로더. image_id별 GT 카테고리 + bbox 노출 |
| `code/modules/metrics.py` | IoU, confusion matrix, P·R·F1 |
| `code/run_step4.py` | Step 4 오케스트레이터 (JSON + 결과 표 CSV) |

## 2. GT 다운로드

`http://images.cocodataset.org/annotations/annotations_trainval2017.zip` (241 MB) → 내부의 val2017 파일만 추출:
- `instances_val2017.json` (20 MB)
- `captions_val2017.json` (4 MB)
- `person_keypoints_val2017.json` (10 MB, 미사용)

(`data/coco_annotations/`는 `.gitignore` 처리되어 GitHub에 안 올라감.)

### 카테고리 정합성 확인
COCO 80 카테고리 이름이 `extract.py`의 `COCO80`과 **정확히 일치** (`couch`, `potted plant`, `dining table`, `tv`, `sports ball`, ... 표기 동일). 추가 매핑 필요 없음.

## 3. 지표 정의

### Object Hallucination Rate (CHAIR-like)
```
baseline_rate = (mentions whose canonical ∉ image GT categories) / total mentions
verified_rate = (supported mentions whose canonical ∉ GT) / supported mentions
```

### Confusion Matrix on "predict unsupported"
시스템의 작업을 "unsupported로 깃발 들기"로 간주.

|  | not in GT (truly hallucinated) | in GT (real) |
| --- | --- | --- |
| predicted unsupported | **TP** | FP |
| predicted supported | FN | **TN** |

### Grounding Acc@0.5
supported mention 중 bbox가 있고 GT에 동일 카테고리가 존재하는 케이스 한정. `max IoU ≥ 0.5` 비율.

## 4. 실행

```powershell
python code/run_step4.py
```

CPU만 사용. 1초 내 완료.

## 5. 결과 (Florence-2-base-ft, 50 images / 73 mentions)

| 항목 | 값 |
| --- | --: |
| n_images | 47 (3장은 0-mention) |
| n_mentions | 73 |
| supported | 69 |
| unsupported | 4 |
| **Baseline Hallucination Rate** | **6/73 = 8.22%** |
| **Verified Hallucination Rate** | **2/69 = 2.90%** |
| Confusion matrix (unsupported task) | TP=4, FP=0, FN=2, TN=67 |
| Precision (unsupported) | 1.0000 |
| Recall (unsupported) | 0.6667 |
| **F1 (unsupported)** | **0.8000** |
| **Grounding Acc@0.5** | **65/67 = 97.01%** |

### 결과 표 (`outputs/metrics/base_result_table.csv`)
| Method | Mentions | Hallucinated | Hall. Rate | Unsupp. F1 | Grd Acc@0.5 |
| --- | --: | --: | --: | --: | --: |
| Florence-2-base-ft caption (baseline) | 73 | 6 | 0.0822 | – | – |
| Florence-2-base-ft verified (ours) | 69 | 2 | 0.0290 | 0.8000 | 0.9701 |

## 6. 해석

- **검증으로 hallucination 약 65% 감소**: 8.22% → 2.90%. 작은 파일럿(50장)이지만 양상은 분명.
- **Perfect precision (1.0)**: 우리가 unsupported로 깃발 든 4건은 모두 GT에도 없음 — 자기검증이 보수적이고 정확함.
- **Imperfect recall (0.667)**: GT에 없는 6개 mention 중 2개가 자기검증을 통과(FN). 이는 *caption hallucination이 OD에도 같은 방향으로 hallucinate한 joint failure*. self-verification의 구조적 한계.
- **Grounding Acc@0.5 97%**: bbox는 매우 정확. supported 판정이 단순 라벨 매칭이 아니라 의미 있는 공간 정합을 동반함.

## 7. 알게 된 점 (Step 5 입력)

1. FN 2건이 정성 분석의 핵심 실패 사례 → Step 5에서 골라내 시각화.
2. TP 4건이 정성 분석의 핵심 성공 사례.
3. caption "table" → canonical `dining table` 매핑이 *식탁이 아닌 책상/콘솔테이블*에서 GT와 불일치 가능. 향후 어휘 정제 후보.
4. baseline 6개 중 3개가 "sports ball" 관련 — caption 어휘 vs OD 어휘 차이. 차후 confusion 분석 별도 산출 가치.

## 8. 변경된 저장소 상태
- 커밋 `5827634` Step 4: COCO GT loader + metrics (CHAIR rate, P/R/F1, Grounding Acc@0.5)
