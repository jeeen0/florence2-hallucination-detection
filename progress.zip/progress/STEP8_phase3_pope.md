# Step 8 (Phase 3) — POPE 외부 벤치마크

> **목표**: COCO val2017 내부 평가만으로는 외부 비교가 불가능하므로, 표준 POPE benchmark[1]를 직접 돌려 Florence-2-large-ft 의 hallucination-related 정확도를 SOTA LVLM과 비교 가능한 형태로 측정한다.

[1] Li et al., *POPE: Evaluating Object Hallucination in Large Vision-Language Models*, EMNLP 2023.

## 1. POPE 데이터 구조

POPE = Polling-based Object Probing Evaluation. COCO val2014 이미지에 대해 "Is there a {object} in the image?" yes/no 질문 형식.

| Split | 의도 | 부정 객체 추출 방식 |
| --- | --- | --- |
| random | 가장 쉬움 | COCO80에서 무작위 |
| popular | 중간 | 자주 등장하는 객체 우선 |
| adversarial | 가장 어려움 | 이미지의 GT 객체와 자주 같이 나타나는 객체 우선 |

다운로드: https://github.com/RUCAIBox/POPE/raw/main/output/coco/coco_pope_{random,popular,adversarial}.json
각 split = 3,000 questions × 500 unique val2014 images (3 split 모두 동일한 500 images 공유).

## 2. 추가된 코드
- `code/run_pope.py` — 다운로드 + OD 캐시 + 평가 자동화

## 3. 평가 방법

```
For each (image, object_name, label):
    detections = Florence-2 large-ft <OD>(image)   # 캐시
    canonicals = { label_to_canonical(d.label, vocab='strict') for d in detections }
    pred = "yes" if object_name in canonicals else "no"
    compare pred vs label
```

OD 한 번 호출에 strict synonym table로 정규화 후 question 객체와 직접 일치 비교.

500장 OD 호출은 캐시(`outputs/pope/od_cache.json`)에 저장 → 어휘 ablation 시 재호출 불필요.

## 4. 결과 — Florence-2-large-ft, strict vocab

| Split | Accuracy | Precision | Recall | F1 | yes-ratio |
| --- | --: | --: | --: | --: | --: |
| **random** | **91.34%** | **99.27%** | 83.65% | **90.79%** | 43.04% |
| **popular** | **90.83%** | 97.36% | 83.65% | **89.99%** | 42.32% |
| **adversarial** | **89.97%** | 95.53% | 83.65% | **89.20%** | 43.34% |

### Confusion matrix (random)
- TP=1218, FP=9, FN=238, TN=1386 → P=0.993, R=0.837

## 5. 문헌 비교 (POPE 원논문 reported 수치)

| 모델 | Random Acc | Popular Acc | Adversarial Acc |
| --- | --: | --: | --: |
| MiniGPT-4 | 78.95% | 75.18% | 72.05% |
| mPLUG-Owl2 | 86.06% | 84.50% | 83.20% |
| InstructBLIP | 87.96% | 86.10% | 83.10% |
| LLaVA-1.5-7B | 88.07% | 87.20% | 84.27% |
| **Florence-2-large-ft (ours)** | **91.34%** | **90.83%** | **89.97%** |

→ Florence-2-large-ft가 POPE 3 splits 모두에서 위 LVLM들을 능가. OD 전용 학습이 객체 존재 yes/no 판정에 강함.

## 6. 핵심 관찰

### 6.1 Precision 매우 높음 (95~99%)
OD가 "있다"고 한 객체는 거의 항상 진짜로 있음. 즉 Florence-2 OD는 **false positive를 거의 안 만듦**. 보수적 모델.

### 6.2 Recall이 일관되게 83.65%
세 split 모두 정확히 같은 recall — 동일한 이미지·동일한 OD 호출이라 yes-truth question 1456개 중 1218개를 잡고 238개를 놓침. 16.35%는 OD가 객체 자체를 못 잡음. (small object / occluded / atypical pose 등)

### 6.3 random→adversarial로 갈수록 F1 하락
- random: 90.79
- popular: 89.99
- adversarial: 89.20

precision 하락(99.3→95.5)이 주된 원인. adversarial은 co-occurring 객체를 prompt에 넣어서 "그럴듯한 거짓"을 만드는데, 거기서 OD가 살짝 더 속음.

### 6.4 yes-ratio 43% (기준 50%)
Florence-2 OD가 평균적으로 "있다"보다 "없다"로 응답하는 경향. 보수적 성향과 일치.

## 7. 페이퍼 활용

- **Result 절**: Florence-2 OD가 다른 LVLM 대비 POPE에서 어떤 위치인지 표로 비교.
- **Discussion**: OD 전용 학습이 "객체 존재 인식"에는 강점, 그러나 16% recall miss는 self-verification의 *Limitation*과 직접 연결됨 (Phase 2 large 500 detailed FP가 small object 위주였던 것과 같은 원인).

## 8. 산출물
| 파일 | 내용 |
| --- | --- |
| `outputs/pope/od_cache.json` | 500 images의 Florence-2 OD raw 출력 (label, canonical, bbox) |
| `outputs/pope/pope_per_question.csv` | 9000 questions × (split, qid, image, object, label, pred) |
| `outputs/pope/pope_metrics.json` | 위 표의 raw 수치 |

## 9. 발견된 이슈 / 보완 사항
1. **이미지 다운로드 ~75 MB** (val2014 500장) — 한 번만 받으면 캐시.
2. POPE 자체 GT는 *완전*하지 않음 — COCO annotation 누락이 곧 GT 누락. 본 평가는 그 한계를 그대로 상속.
3. yes/no 단일 질문 형식 한계 — 본문 페이퍼에서는 "object hallucination"에 한정된 평가임을 명시.
4. recall이 정확히 83.65%로 세 split이 동일한 점은 *같은 OD 출력 + 같은 yes-question 집합* 때문. 정상.

## 10. 변경된 저장소 상태
- 커밋 `7fcfdde` Add bootstrap CIs + run_compare_all
- (다음) Phase 3 POPE 산출물은 outputs/ 안이라 gitignore. POPE 평가기 코드 자체는 이미 푸시됨 (`698b1a4`, `1ae397f`).

## 11. 다음 (Phase 4 — Cross-Model Verification)
self-verification의 한계를 *실증* — Florence-2 caption 대신 **BLIP-2 caption**을 입력으로 사용하고 그것을 Florence-2 OD로 검증.
- 같은 200장에서 self vs cross 비교
- 두 captioner가 다른 방향으로 hallucinate하는지, 그것을 OD가 더 잘 잡는지 측정
