# Step 7 (Phase 2) — Strict 어휘 + 500장 본실험 + bootstrap CIs

> **목표**: Phase 1에서 정제한 strict synonym 맵으로, Florence-2-large-ft + 500장 + 두 가지 caption prompt(`<CAPTION>`, `<DETAILED_CAPTION>`) 본 실험을 돌려 정직한 hallucination 검출 성능을 측정한다.

## 1. 환경/입력

- 모델: `microsoft/Florence-2-large-ft`
- 데이터: COCO val2017 500장 (seed=7, `instances_val2017.json`의 5000 ID 풀에서 무작위)
- 어휘: **strict** (Phase 1에서 `baseball/table/monitor/stove/plant` 제거)
- prompt: `<CAPTION>`, `<DETAILED_CAPTION>` 각각 별도 실행

## 2. 추가/변경된 코드

| 파일 | 변경 |
| --- | --- |
| `code/modules/metrics.py` | `bootstrap_ci()`, `mention_rate()`, `f1_from_flags()` 추가 |
| `code/run_step4.py` | baseline / verified rate / F1에 대해 95% 부트스트랩 CI 계산 추가 |
| `code/run_compare_all.py` | `outputs/metrics/*_metrics.json` 자동 수집 → 비교 표 |
| `code/extract_only.py` | 모델 호출 없이 caption CSV로부터 mention 재추출 (vocab ablation 비용 절감) |

## 3. 실행 순서
```powershell
# CAPTION 500
python code/run_step2.py --n 500 --model microsoft/Florence-2-large-ft --seed 7 --prompt caption --vocab strict \
    --out-caption outputs/captions/large_strict_caption_500.csv \
    --out-mentions outputs/captions/large_strict_extracted_500.csv
python code/run_step3.py --model microsoft/Florence-2-large-ft --vocab strict \
    --caption-csv outputs/captions/large_strict_caption_500.csv \
    --mentions-csv outputs/captions/large_strict_extracted_500.csv \
    --out-csv outputs/grounding/large_strict_500_grounding.csv \
    --out-viz-dir outputs/visualizations/large_strict_500
python code/run_step4.py --grounding-csv outputs/grounding/large_strict_500_grounding.csv \
    --out-json outputs/metrics/large_strict_500_metrics.json \
    --out-table outputs/metrics/large_strict_500_result_table.csv \
    --label "Florence-2-large-ft (strict, 500, CAPTION)"

# DETAILED 500 (동일 패턴, 파일명만 다름)
python code/run_step2.py --n 500 --prompt detailed --vocab strict ... [DETAILED 출력 파일들]
python code/run_step3.py ...
python code/run_step4.py ...

# 종합 비교
python code/run_compare_all.py
```

## 4. 결과

### 4.1 종합 비교 표 (모든 실험)

| Label | n_img | n_mention | Baseline Hall% (95% CI) | Verified Hall% (95% CI) | P | R | F1 (95% CI) | GrdAcc@0.5 |
| --- | --: | --: | --: | --: | --: | --: | --: | --: |
| base-ft 50 (aggressive) | 47 | 73 | 8.22% | 2.90% | 1.00 | 0.67 | 0.800 | 97.01% |
| **base-ft 50 (strict)** | 44 | 68 | 4.41% [0.00, 10.29] | 2.99% [0.00, 7.46] | 1.00 | 0.33 | 0.500 [0.00, 1.00] | 96.92% |
| large-ft 100 (aggressive) | 95 | 159 | 3.77% | 1.29% | 1.00 | 0.67 | 0.800 | 94.12% |
| **large-ft 100 (strict)** | 91 | 150 | 0.67% [0.00, 2.00] | 0.67% [0.00, 2.00] | – | – | 0.000 [0.00, 0.00] | 93.96% |
| **large-ft 500 (strict, CAPTION)** | 465 | **732** | **2.46% [1.50, 3.55]** | **0.70% [0.14, 1.39]** | **0.93** | **0.72** | **0.812 [0.636, 0.941]** | **95.65%** |
| **large-ft 500 (strict, DETAILED)** | 462 | **1121** | **6.07% [4.73, 7.40]** | **2.99% [2.05, 4.01]** | **0.72** | **0.53** | **0.610 [0.495, 0.710]** | **93.94%** |

`-` = TP=0이라 P/R 정의 불가.

### 4.2 통계적 유의성
- **500 CAPTION**: baseline CI [1.50, 3.55] vs verified CI [0.14, 1.39] → **겹치지 않음** → α=.05에서 통계적으로 유의한 감소.
- **500 DETAILED**: baseline [4.73, 7.40] vs verified [2.05, 4.01] → **겹치지 않음** → 유의함.
- 100장 strict: CI 매우 넓음 (1건 hallucination만) → 신뢰 못 함.

### 4.3 FP (Over-flag) 분석 — self-review 핵심
| 실험 | FP 수 | 패턴 |
| --- | --: | --- |
| CAPTION 500 | 1 | `sink` 1건. caption은 "two sinks and a television"이라 했는데 OD는 sink를 못 잡음. *OD recall의 한계* |
| DETAILED 500 | 14 | bowl(3), spoon(2), bottle(2), couch(2), bird(1), sink(1), person(1), bench(1), car(1) — **작은 식기류·욕실 객체에 집중**. detailed caption이 더 잘게 객체를 묘사하지만 OD가 작은 객체를 못 잡음 |

→ FP의 근본 원인은 *synonym 매핑 오류* (Phase 1에서 제거됨) 가 아니라 **detection model의 small-object recall 한계**. 이게 진짜 self-verification의 한계.

### 4.4 비교: CAPTION vs DETAILED
- DETAILED는 mention 53% 더 많음 (732 → 1121).
- 그러나 baseline hallucination rate가 **2.5× 더 높음** (2.46% → 6.07%) — *긴 caption은 더 hallucinate*. 문헌과 일치.
- DETAILED 환경에서 verification의 recall이 떨어짐 (0.72 → 0.53). 작은 객체 묘사가 늘면서 OD가 못 잡는 경우 증가.
- Precision도 떨어짐 (0.93 → 0.72). 위 FP 14건의 영향.

## 5. 발견된 이슈 / 보완 사항

1. **Phase 1의 sanity check (large-ft 100 strict)** 에서 unsupported가 0건이라 F1=0이었음 → 100장이 통계적으로 부족했음 (hallucination 1건만 발생). 500장으로 늘려서 정상적인 F1 측정 확보됨. 100장 결과는 *underpowered* 이라 보고서에서 빼거나 "표본 부족" 주석.
2. **DETAILED FPs가 14건**: 모두 작은 객체 → caption은 정확한데 OD recall이 한계. 보고서 Limitation 절에 추가 ("OD 모델의 small-object detection 한계가 self-verification 성능의 상한").
3. **base-ft 50 strict F1 = 0.5** (TP=1, FN=2) — sample size 너무 작음. CI [0, 1]. 정성적 참고용으로만.
4. 본 단계에서 IoU=0.5 외의 임계값(0.3, 0.7)은 보고 안 함 — Phase 5에서 ablation 가능.

## 6. 변경된 저장소 상태
- 커밋 `d03f683` Phase 1: strict synonym vocab
- 커밋 `1ae397f` Bootstrap CIs, POPE evaluator, extract_only
- 커밋 `698b1a4` Phase 4 scaffolding: BLIP-2 + cross orchestrator
- (다음 커밋) bootstrap CI를 run_step4에 통합 + 종합 비교 스크립트

## 7. 다음 (Phase 3 — POPE 외부 벤치마크)
- 500 val2014 이미지에 대해 3 splits × 3,000 질문 = 9,000 yes/no 질문
- Florence-2-large-ft `<OD>` 결과로 답변 → POPE 표준 accuracy/F1 계산
- 외부 비교를 위한 절대 평가 (기존 LVLM 논문들과 직접 비교 가능)
