# Progress Log (local only)

이 폴더는 `.gitignore`에 등록되어 GitHub에 올라가지 **않습니다**. Step마다 무엇을 했는지, 무엇이 막혔는지, 어떻게 해결했는지를 작성자(본인)가 다시 볼 수 있도록 정리한 작업 일지입니다.

## 파일 명명 규칙

- `STEP{N}_<short-title>.md` — 각 Step 작업 로그
- `NOTES.md` — 자잘한 메모

## 인덱스

### Pass 1 — initial sweep (aggressive vocab)
| Step | 파일 | 상태 |
| --- | --- | --- |
| 1 | [STEP1_environment_and_smoke_test.md](STEP1_environment_and_smoke_test.md) | ✅ 완료 |
| 2 | [STEP2_caption_and_mention_extraction.md](STEP2_caption_and_mention_extraction.md) | ✅ 완료 |
| 3 | [STEP3_grounding_verification.md](STEP3_grounding_verification.md) | ✅ 완료 |
| 4 | [STEP4_metrics.md](STEP4_metrics.md) | ✅ 완료 |
| 5 | [STEP5_qualitative_cases.md](STEP5_qualitative_cases.md) | ✅ 완료 |
| 6 | [STEP6_large_ft_full_experiment.md](STEP6_large_ft_full_experiment.md) | ✅ 완료 |

### Pass 2 — research-grade methodology (after self-critique)
| Phase | 파일 | 핵심 결과 | 상태 |
| --- | --- | --- | --- |
| 1 | (extract.py refactor) | strict vocab 도입 — `baseball/table/monitor/stove/plant` 매핑 제거 | ✅ 완료 |
| 2 | [STEP7_phase2_strict_500.md](STEP7_phase2_strict_500.md) | large-ft 500 strict CAPTION: F1 0.812, Hall 2.46→0.70%, bootstrap CIs | ✅ 완료 |
| 3 | [STEP8_phase3_pope.md](STEP8_phase3_pope.md) | POPE: 91.34/90.83/89.97% acc, LLaVA·InstructBLIP·mPLUG-Owl2 상회 | ✅ 완료 |
| 4 | [STEP9_phase4_cross_model.md](STEP9_phase4_cross_model.md) | BLIP cross-model: recall 한계 OD에서 발생 입증 | ✅ 완료 |
| 5 | [STEP10_phase5_vocab_ablation.md](STEP10_phase5_vocab_ablation.md) | aggressive vocab이 baseline +80% 부풀림 정량 입증 | ✅ 완료 |
| 6 | `paper/draft_ko.md` | IPIU2026 한국어 논문 전면 재작성 (7장 + 정성 그림) | ✅ 완료 |
| 11 | [STEP11_final_self_review.md](STEP11_final_self_review.md) | 최종 self-review: 결과 일관성/잔여 작업 점검 | ✅ 완료 |

### Pass 3 — Option C 보강 실험 (외부 비평 대응 후)
| Phase | 파일 | 핵심 결과 | 상태 |
| --- | --- | --- | --- |
| 12 | [STEP12_optionC_extensions.md](STEP12_optionC_extensions.md) | 1000장 (F1 0.688) + multi-seed (mean 0.786) + cross-500 + phrase-grounding ablation (F1 0) | ✅ 완료 |

### 학교 4090 작업용 가이드
- [SCHOOL_4090_GUIDE.md](SCHOOL_4090_GUIDE.md) — 학교 머신에서 따라할 수 있는 step-by-step 가이드 (메인 2000장 + LLaVA cross + DETAILED 2000)
