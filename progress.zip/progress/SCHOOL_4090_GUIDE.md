# 학교 4090 작업 가이드 — 따라하기 가이드

> 이 파일은 progress/ 안에 있어서 GitHub에 안 올라갑니다. 학교 가기 전에 **본인 메일/Google Drive/USB에 복사** 해두세요.

---

## 📋 미리 준비 (집에서 하기)

이 파일 + 학교 머신에서 새로 클론할 GitHub URL: `https://github.com/jeeen0/florence2-hallucination-detection`

학교 머신 사양 확인 사항:
- [ ] Windows 또는 Linux (둘 다 가능)
- [ ] Python 3.10 이상 (`python --version` 확인)
- [ ] CUDA 12.x 드라이버 (`nvidia-smi` 로 확인, 보통 설치돼 있음)
- [ ] 디스크 여유 공간 **20 GB 이상** (모델 + 결과)
- [ ] 인터넷 (HuggingFace · COCO 다운로드용)

---

## 🛠️ Phase 0: 학교 머신 셋업 (한 번만, ~15분)

### Windows (PowerShell) 기준

```powershell
# 1. 작업 폴더로 이동
cd C:\Users\<본인id>\Documents
git clone https://github.com/jeeen0/florence2-hallucination-detection.git
cd florence2-hallucination-detection

# 2. venv 생성 + 활성화
python -m venv .venv
.\.venv\Scripts\Activate.ps1

# 3. PyTorch + CUDA 12.1 설치 (4090에 맞음)
python -m pip install --upgrade pip
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121

# 4. 나머지 의존성
pip install -r code/env/requirements.txt

# 5. 동작 확인
python -c "import torch; print('CUDA:', torch.cuda.is_available(), torch.cuda.get_device_name(0))"
# → 출력 예: CUDA: True NVIDIA GeForce RTX 4090
```

### Linux/Ubuntu (bash) 기준

```bash
cd ~/work
git clone https://github.com/jeeen0/florence2-hallucination-detection.git
cd florence2-hallucination-detection

python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install -r code/env/requirements.txt
python -c "import torch; print('CUDA:', torch.cuda.is_available(), torch.cuda.get_device_name(0))"
```

> ⚠️ **첫 모델 실행 시** Florence-2-large-ft (~1.5GB) 가 HF에서 자동 다운로드됩니다. 인터넷 필요.

### COCO 어노테이션 다운로드 (한 번만, ~241MB)

```powershell
cd data/coco_annotations
# Windows PowerShell:
Invoke-WebRequest -Uri "http://images.cocodataset.org/annotations/annotations_trainval2017.zip" -OutFile coco_anno.zip
python -c "import zipfile,os,shutil; z=zipfile.ZipFile('coco_anno.zip'); [z.extract(n,'.') for n in z.namelist() if 'val2017' in n]; z.close(); [shutil.move(os.path.join('annotations',f),'.') for f in os.listdir('annotations')]; os.rmdir('annotations'); os.remove('coco_anno.zip')"
cd ../..
```

(또는 Linux 에선 `curl -L -o ... && unzip ...`)

---

## 🚀 4090에서 할 우선순위 작업 3가지

| # | 작업 | 효과 | 4090 예상 시간 |
|---|---|---|---:|
| 🅰️ | **메인 2000장 (seed 7)** | F1 CI 더 좁힘, 통계 자신감 ↑ | ~20분 |
| 🅱️ | **LLaVA-1.5-7B cross-model 500장** | 강력한 cross-model 비교 | ~30분 |
| 🅲 | DETAILED 2000장 (선택) | richer 결과 | ~25분 |

🅰️ + 🅱️ 만 해도 페이퍼 가치 큼.

---

## 🅰️ 메인 2000장 실험

### Step 1 — Caption + mention 추출 (2000장, ~10분)

```powershell
python code/run_step2.py `
  --n 2000 `
  --model microsoft/Florence-2-large-ft `
  --seed 7 `
  --prompt caption `
  --vocab strict `
  --out-caption outputs/captions/large_strict_caption_2000.csv `
  --out-mentions outputs/captions/large_strict_extracted_2000.csv
```

기대 출력 마지막 줄:
```
images=2000  total_mentions=~2800
```

### Step 2 — OD 검증 (~10분)

```powershell
mkdir outputs/visualizations/large_strict_2000 -Force
python code/run_step3.py `
  --model microsoft/Florence-2-large-ft `
  --vocab strict `
  --caption-csv outputs/captions/large_strict_caption_2000.csv `
  --mentions-csv outputs/captions/large_strict_extracted_2000.csv `
  --out-csv outputs/grounding/large_strict_2000_grounding.csv `
  --out-viz-dir outputs/visualizations/large_strict_2000
```

기대 출력:
```
total_mentions=~2800  supported=~2740  unsupported=~60
```

### Step 3 — 메트릭

```powershell
python code/run_step4.py `
  --grounding-csv outputs/grounding/large_strict_2000_grounding.csv `
  --out-json outputs/metrics/large_strict_2000_metrics.json `
  --out-table outputs/metrics/large_strict_2000_result_table.csv `
  --label "Florence-2-large-ft (strict, 2000, CAPTION)"
```

**이 결과의 F1과 CI를 paper draft 표 1에 갱신.**

기대 수치 (예상):
- Baseline ~2.3%, Verified ~0.8%
- F1 ≈ 0.65~0.75 (CI 폭 ±0.10 정도로 좁아짐)

---

## 🅱️ LLaVA-1.5-7B Cross-Model 실험

LLaVA-7B 는 fp16 으로 약 14 GB → **4090 24 GB 면 여유**. (3070 8GB 로는 불가능했던 작업.)

### Step 0 — LLaVA 코드 추가 (1회만)

`code/llava_runner.py` 파일을 새로 만드세요:

```python
"""LLaVA-1.5-7B caption backend for cross-model verification."""
from __future__ import annotations
import torch
from PIL import Image
from transformers import LlavaForConditionalGeneration, AutoProcessor


class LlavaCaptioner:
    def __init__(
        self,
        model_id: str = "llava-hf/llava-1.5-7b-hf",
        device: str | None = None,
        dtype: torch.dtype | None = None,
    ) -> None:
        if device is None:
            device = "cuda" if torch.cuda.is_available() else "cpu"
        if dtype is None:
            dtype = torch.float16 if device == "cuda" else torch.float32
        self.device = device
        self.dtype = dtype
        self.model_id = model_id
        self.processor = AutoProcessor.from_pretrained(model_id)
        self.model = (
            LlavaForConditionalGeneration.from_pretrained(model_id, torch_dtype=dtype)
            .to(device)
            .eval()
        )

    @torch.inference_mode()
    def caption(self, image: Image.Image, max_new_tokens: int = 80) -> str:
        prompt = "USER: <image>\nDescribe this image briefly.\nASSISTANT:"
        inputs = self.processor(images=image, text=prompt, return_tensors="pt").to(
            self.device, self.dtype
        )
        out = self.model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            num_beams=1,
        )
        text = self.processor.batch_decode(out, skip_special_tokens=True)[0]
        if "ASSISTANT:" in text:
            text = text.split("ASSISTANT:", 1)[1].strip()
        return text
```

### Step 1 — run_cross.py 의 LLaVA 변형 만들기 (1회만)

`code/run_cross_llava.py` 새 파일:

```python
"""Cross-model verification with LLaVA-1.5-7B captions + Florence-2 OD."""
from __future__ import annotations
import argparse, csv
from pathlib import Path
from PIL import Image

from llava_runner import LlavaCaptioner
from florence2 import Florence2Runner
from modules.extract import extract_mentions
from modules.verify import detect_objects, verify_with_detections

REPO_ROOT = Path(__file__).resolve().parents[1]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--florence-caption-csv", type=Path,
                    default=REPO_ROOT / "outputs/captions/large_strict_caption_2000.csv")
    ap.add_argument("--n", type=int, default=500)
    ap.add_argument("--image-dir", type=Path, default=REPO_ROOT / "data/coco_val")
    ap.add_argument("--vocab", default="strict")
    ap.add_argument("--out-llava-caption", type=Path,
                    default=REPO_ROOT / "outputs/cross/llava_caption_500.csv")
    ap.add_argument("--out-self-grounding", type=Path,
                    default=REPO_ROOT / "outputs/cross/llava_self_grounding_500.csv")
    ap.add_argument("--out-cross-grounding", type=Path,
                    default=REPO_ROOT / "outputs/cross/llava_cross_grounding_500.csv")
    args = ap.parse_args()

    # Florence-2 captions to reuse for self
    with args.florence_caption_csv.open("r", encoding="utf-8") as f:
        florence = list(csv.DictReader(f))[: args.n]

    print(f"[llava-cross] loading LLaVA")
    llava = LlavaCaptioner()
    llava_caps: dict[int, str] = {}
    for i, row in enumerate(florence, 1):
        iid = int(row["image_id"])
        image = Image.open(args.image_dir / f"{iid:012d}.jpg").convert("RGB")
        llava_caps[iid] = llava.caption(image)
        if i % 25 == 0 or i == len(florence):
            print(f"  [{i}/{len(florence)}] llava ok")

    del llava
    import torch; torch.cuda.empty_cache()

    args.out_llava_caption.parent.mkdir(parents=True, exist_ok=True)
    with args.out_llava_caption.open("w", encoding="utf-8", newline="") as f:
        w = csv.writer(f); w.writerow(["image_id", "caption"])
        for r in florence: w.writerow([int(r["image_id"]), llava_caps[int(r["image_id"])]])

    print(f"[llava-cross] loading Florence-2 OD")
    runner = Florence2Runner(model_id="microsoft/Florence-2-large-ft")

    def _write(path, rows):
        with path.open("w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["image_id", "surface", "canonical", "status", "x1","y1","x2","y2"])
            for r in rows: w.writerow(r)

    self_rows, cross_rows = [], []
    for i, r in enumerate(florence, 1):
        iid = int(r["image_id"])
        image = Image.open(args.image_dir / f"{iid:012d}.jpg").convert("RGB")
        dets = detect_objects(runner, image, vocab=args.vocab)
        for ms_src, target in [(r["caption"], self_rows), (llava_caps[iid], cross_rows)]:
            mentions = extract_mentions(ms_src, vocab=args.vocab)
            verds = verify_with_detections(mentions, dets)
            for v in verds:
                bb = v.bbox if v.bbox else (None,)*4
                target.append((iid, v.mention.surface, v.mention.canonical,
                               "supported" if v.supported else "unsupported", *bb))
        if i % 25 == 0 or i == len(florence):
            print(f"  [{i}/{len(florence)}] od ok")

    _write(args.out_self_grounding, self_rows)
    _write(args.out_cross_grounding, cross_rows)
    print(f"Done. self={len(self_rows)}, cross={len(cross_rows)}")


if __name__ == "__main__":
    main()
```

### Step 2 — 실행 (~30분, 처음엔 LLaVA 다운로드 ~14GB 추가)

```powershell
python code/run_cross_llava.py --n 500
```

처음 실행 시 `llava-hf/llava-1.5-7b-hf` 가중치 (~13.5 GB) 가 HF 에서 자동 다운로드. **인터넷·디스크 확보** 필요.

### Step 3 — 메트릭

```powershell
python code/run_step4.py `
  --grounding-csv outputs/cross/llava_self_grounding_500.csv `
  --out-json outputs/metrics/llava_self_500_metrics.json `
  --out-table outputs/metrics/llava_self_500_result_table.csv `
  --label "Cross500 Self (F2 cap + F2 OD)"

python code/run_step4.py `
  --grounding-csv outputs/cross/llava_cross_grounding_500.csv `
  --out-json outputs/metrics/llava_cross_500_metrics.json `
  --out-table outputs/metrics/llava_cross_500_result_table.csv `
  --label "Cross500 Cross (LLaVA cap + F2 OD)"
```

**핵심 비교**: BLIP-large cross (이미 측정됨, F1=0.774) vs **LLaVA cross (새로 측정)**. LLaVA 가 BLIP 보다 더 잘 hallucinate 하는지 / 적게 하는지 확인.

기대 결과:
- LLaVA-7B baseline ~3~6% (BLIP 4.74% 정도와 비슷하거나 약간 높을 수도)
- F1 ~0.7 부근 — 만약 BLIP과 비슷하면 "cross-model 결과는 caption model 종류에 robust" 강한 메시지

---

## 🅲 (선택) DETAILED 2000장

```powershell
python code/run_step2.py `
  --n 2000 `
  --model microsoft/Florence-2-large-ft `
  --seed 7 `
  --prompt detailed `
  --vocab strict `
  --out-caption outputs/captions/large_strict_detailed_2000.csv `
  --out-mentions outputs/captions/large_strict_detailed_extracted_2000.csv

mkdir outputs/visualizations/large_detailed_2000 -Force
python code/run_step3.py `
  --model microsoft/Florence-2-large-ft `
  --vocab strict `
  --caption-csv outputs/captions/large_strict_detailed_2000.csv `
  --mentions-csv outputs/captions/large_strict_detailed_extracted_2000.csv `
  --out-csv outputs/grounding/large_strict_detailed_2000_grounding.csv `
  --out-viz-dir outputs/visualizations/large_detailed_2000

python code/run_step4.py `
  --grounding-csv outputs/grounding/large_strict_detailed_2000_grounding.csv `
  --out-json outputs/metrics/large_strict_detailed_2000_metrics.json `
  --out-table outputs/metrics/large_strict_detailed_2000_result_table.csv `
  --label "Florence-2-large-ft (strict, 2000, DETAILED)"
```

기대 시간: ~25분.

---

## 📦 결과 통합 + 비교 표

모든 실험 끝나면:

```powershell
python code/run_compare_all.py
```

→ `outputs/metrics/all_compare.md` 자동 갱신. 모든 메트릭 JSON 을 한 표로.

---

## 💾 집으로 가져올 것

학교에서 만든 새 결과 파일들:

```
outputs/metrics/large_strict_2000_metrics.json        ← 메인 2000
outputs/metrics/large_strict_detailed_2000_metrics.json  ← DETAILED 2000 (선택)
outputs/metrics/llava_self_500_metrics.json
outputs/metrics/llava_cross_500_metrics.json
outputs/metrics/all_compare.md                        ← 갱신된 비교 표
outputs/cross/llava_caption_500.csv
```

옮기는 방법:
- 옵션 A: USB 로 복사
- 옵션 B: 학교 머신에서 `git status` 후 → push 안 하고 USB 이동 (outputs/ 는 gitignore)
- 옵션 C: 결과 폴더만 zip → 메일 / 클라우드

```powershell
# 결과만 zip
Compress-Archive -Path outputs\metrics, outputs\cross\llava_*.csv -DestinationPath florence2_4090_results.zip
```

집에 와서 `florence2_4090_results.zip` 압축 풀어 `outputs/` 폴더에 덮어쓰기.

---

## 🐞 문제 해결

### Q1. `transformers 5.x` 호환 안 됨 (`AttributeError: forced_bos_token_id`)
A. `requirements.txt` 가 `transformers==4.49.0` 핀돼 있어서 자동으로 4.49 설치됨. 그래도 안 되면 수동:
```powershell
pip install "transformers==4.49.0"
```

### Q2. LLaVA-7B 가 OOM
A. 4090 24GB 면 fp16 으로 충분. 그래도 안 되면 8-bit 양자화:
```powershell
pip install bitsandbytes
```
`llava_runner.py` 의 model 로딩 부분에 `load_in_8bit=True` 추가.

### Q3. HF 다운로드가 느림
A. 환경변수 설정:
```powershell
$env:HF_HUB_ENABLE_HF_TRANSFER = "1"
pip install hf_transfer
```
다음번부터 빨라짐.

### Q4. COCO 이미지 다운로드 너무 느림
A. 한 번에 2000장 받기 너무 오래 걸리면 `code/data_utils.py` 의 `fetch_val2017_image` 를 ThreadPoolExecutor 로 병렬화하면 4~8배 빨라짐. 다만 현재 코드대로도 ~5분이면 받음.

### Q5. CUDA out of memory 메시지
A. `code/florence2/model.py` 의 `dtype=torch.float16` 그대로 (4090 에선 충분). LLaVA 로딩 후엔 반드시 `del llava; torch.cuda.empty_cache()` (스크립트에 이미 있음).

### Q6. 결과를 paper 에 어떻게 반영?
A. 새 메트릭 JSON 들을 가져와 `outputs/metrics/` 에 두고, 집에서 `run_compare_all.py` 한 번 더 실행 → `all_compare.md` 보고 `paper/draft_ko.md` 의 표를 갱신.

---

## ✅ 최종 체크리스트

학교 작업 끝나기 전:

- [ ] `large_strict_2000_metrics.json` 생성됨
- [ ] LLaVA cross-model 메트릭 2개 생성됨 (`llava_self_500`, `llava_cross_500`)
- [ ] `run_compare_all.py` 한 번 실행해 `all_compare.md` 업데이트
- [ ] 위 4개 결과 파일 + LLaVA caption CSV → zip
- [ ] zip 을 USB / 메일 / 클라우드에 복사
- [ ] 집에 와서 압축 풀고 paper 갱신

---

## 📊 페이퍼 갱신 시 핵심 변경 위치

`paper/draft_ko.md` 에서:

1. **표 1** — 1000장 → 2000장 결과로 교체 (F1 / CI 갱신)
2. **표 1b** — retention 통계 2000장 수치로
3. **§5.4 Cross-model** — BLIP 대신 LLaVA 결과로 교체 (또는 둘 다 표에 행으로 비교 가능: BLIP / LLaVA / Self)
4. **§4.1 데이터셋** — "주 실험 2000장" 으로 갱신
5. **§4.2 모델 환경** — "본 실험은 RTX 4090 24GB 사용" 추가
6. **참고문헌** — LLaVA[6] 인용 강화

---

## 🎯 결과가 안 좋게 나오면?

가능 시나리오와 대응:

| 시나리오 | 대응 |
|---|---|
| 2000장 F1 이 0.5 이하로 떨어짐 | 정직하게 보고. "표본이 커지면서 F1 안정화" 로 해석. precision 만 보고도 가능 |
| LLaVA cross 가 BLIP 과 거의 같음 | "captioner 변경에 robust" 강력 증거 → 페이퍼 contribution 강화 |
| LLaVA cross 가 self 보다 *훨씬* 잘 잡힘 | self-verification 한계가 실증됨 → 페이퍼 메시지 더 강함 |
| LLaVA OOM | bitsandbytes 8bit / Qwen2-VL-2B 등 작은 모델로 교체 |

어떤 결과가 나오든 **정직하게 보고** 하는 게 페이퍼 가치 ↑.

---

## 📞 막히면

집에서 작업한 메인 머신의 코드와 결과가 GitHub 에 있으니까:
- 학교 머신에서 `git pull` 로 최신 코드 받기
- 어디서 막혔는지 메모해두고 집에 와서 디버그

---

문서 끝. 이 가이드는 GitHub 에 안 올라가므로 **반드시** 본인 메일/Drive 에 복사해두세요!
