# Step 6 — Florence-2-large-ft 대규모 실험 (100 images)

> **목표**: base-ft에서 검증된 파이프라인을 더 큰 모델(`microsoft/Florence-2-large-ft`, 약 770M params)과 더 큰 분할(100 images, val2017 전체 5,000장에서 시드 7로 추출)에서 재확인한다.

## 1. 분할 / 모델 변경 사항

| 항목 | base-ft 실험 (Step 1~5) | large-ft 실험 (Step 6) |
| --- | --- | --- |
| 모델 | Florence-2-base-ft (~230M) | Florence-2-large-ft (~770M) |
| 가중치 크기 | ~470 MB | ~1.5 GB |
| 이미지 수 | 50 | 100 |
| ID 풀 | `CANDIDATE_IDS` (하드코딩 100개) | `instances_val2017.json` 전체 (5,000) |
| Seed | 42 | 7 |

`data_utils.collect_val2017_images()` 에 `gt_path` 파라미터 추가 → GT JSON이 존재할 때 자동으로 전체 ID 풀에서 샘플링. fallback은 기존 CANDIDATE_IDS.

## 2. 실행 순서
```powershell
# 2-1: caption + mention 추출 (Step 2 재사용)
python code/run_step2.py --n 100 --model microsoft/Florence-2-large-ft --seed 7 \
    --out-caption outputs/captions/large_caption_100.csv \
    --out-mentions outputs/captions/large_extracted_objects.csv

# 2-2: <OD> 검증 (Step 3 재사용)
python code/run_step3.py --model microsoft/Florence-2-large-ft \
    --caption-csv outputs/captions/large_caption_100.csv \
    --mentions-csv outputs/captions/large_extracted_objects.csv \
    --out-csv outputs/grounding/large_grounding_results.csv \
    --out-viz-dir outputs/visualizations/large

# 2-3: metric 계산 (Step 4 재사용)
python code/run_step4.py \
    --grounding-csv outputs/grounding/large_grounding_results.csv \
    --out-json outputs/metrics/large_metrics.json \
    --out-table outputs/metrics/large_result_table.csv \
    --label Florence-2-large-ft

# 2-4: 정성 케이스 (Step 5 재사용)
python code/run_step5.py \
    --grounding-csv outputs/grounding/large_grounding_results.csv \
    --caption-csv outputs/captions/large_caption_100.csv \
    --viz-dir outputs/visualizations/large \
    --out-dir outputs/qualitative_large

# 2-5: 두 실험 통합 비교 표
python code/run_compare.py
```

## 3. 도중에 잡힌 버그 (수정 완료)

`pathlib.Path.relative_to(REPO_ROOT)` 가 user-provided 상대경로(`outputs/...`)에 대해 `ValueError` 발생.

해결: 마지막 print 문에서 `.relative_to(REPO_ROOT)` 제거하고 그냥 경로 그대로 출력. `run_step2/3/4/5.py` 전체에 동일 패치 (`bdbafe9`).

CSV/JSON 자체는 정상 저장되었으므로 데이터 손실 없음.

## 4. 결과

### 4.1 large-ft 단일 결과
```
images=95   (5장은 0-mention)
mentions=159
supported=155
unsupported=4
Baseline:    6/159  =  3.77%
Verified:    2/155  =  1.29%
P/R/F1:      1.0000 / 0.6667 / 0.8000
Grd Acc@0.5: 144/153 = 94.12%
```

### 4.2 base-ft (50) vs large-ft (100) 비교 표

| Method | Mentions | Hallu. ↓ | Hall. Rate ↓ | Unsupp. F1 ↑ | Grd Acc@0.5 ↑ |
| --- | --: | --: | --: | --: | --: |
| base-ft `<CAPTION>` (baseline) | 73 | 6 | 8.22% | – | – |
| base-ft verified (ours) | 69 | 2 | **2.90%** | **0.8000** | **0.9701** |
| large-ft `<CAPTION>` (baseline) | 159 | 6 | 3.77% | – | – |
| large-ft verified (ours) | 155 | 2 | **1.29%** | **0.8000** | **0.9412** |

산출 파일:
- `outputs/metrics/large_metrics.json` — 모든 raw 수치
- `outputs/metrics/large_result_table.csv` — 2-row 결과 표
- `outputs/metrics/compare_table.csv` / `compare_table.md` — base vs large 통합

### 4.3 핵심 관찰

1. **모델 규모와 baseline hallucination**: large-ft가 base-ft보다 baseline hallucination rate 절대값이 절반 이하 (8.22 → 3.77%). 큰 모델일수록 caption이 시각적 근거에 더 충실.
2. **상대적 감소율은 비슷**: 두 모델 모두 검증 후 약 ⅔ 감소. 본 검증 파이프라인은 모델 규모와 무관하게 일관된 효과를 보임.
3. **F1 0.8000 우연 일치**: 두 분할 모두 confusion matrix가 TP=4, FP=0, FN=2로 같은 형태 (TN만 67 vs 153). 표본이 더 커지면 자연스럽게 갈라질 것으로 예상되나, 본 파일럿에서는 두 모델의 *결정 경계 형태*가 비슷함을 보임.
4. **Grounding Acc@0.5 소폭 하락**: 97.01% → 94.12%. 분할이 더 다양해지면서 어려운 케이스가 늘어 bbox 정확도가 약간 감소.

### 4.4 large-ft 정성 케이스 요약 (`outputs/qualitative_large/cases.md`)
- TP = 4: 모두 supported 4건 (large-ft 도 base-ft 와 비슷한 *baseball / bowl* 유형으로 짐작; 자세한 항목은 cases.md 참조).
- FN = 2: 동일하게 joint hallucination 형태.
- FP = 0: large-ft에서도 over-flag 없음.

## 5. paper draft 반영
- 표 1을 4행 통합 표로 교체.
- 요약·서론·실험·결과·결론에 large-ft 수치 추가.
- 데이터셋 절을 "두 분할 (pilot 50 + main 100)" 구조로 재구성.
- 4.2 구현 세부에 두 모델 파라미터 수 명시.

## 6. 추가된 코드 / 변경
- `code/run_compare.py` (신규): base vs large metrics JSON → 통합 CSV/MD.
- `code/data_utils.py`: `gt_path` 인자 추가, GT JSON 기반 ID 풀 옵션.
- `code/run_step2.py`: `--gt-json` 인자 추가, 존재 시 자동 사용.
- `code/run_step2/3/4/5.py`: `relative_to` 크래시 수정.

## 7. 변경된 저장소 상태
- 커밋 `35a2f5e` Add GT-based sampling and IPIU2026 Korean paper draft
- 커밋 `bdbafe9` Fix .relative_to crash when user passes relative output paths
- (다음 커밋) Step 6 large-ft 결과 + compare 스크립트
