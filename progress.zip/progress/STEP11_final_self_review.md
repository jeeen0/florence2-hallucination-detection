# Step 11 — 최종 self-review (Pass 2 종료 시점)

> **목적**: Phase 1~6 (Pass 2) 가 끝난 후 결과·코드·논문의 일관성과 누락점을 점검한다.

## 1. 결과 일관성 확인

논문 draft (`paper/draft_ko.md`) 의 모든 수치는 `outputs/metrics/*_metrics.json` 의 raw 값과 직접 일치한다.

| 논문 수치 | 출처 JSON | OK |
| --- | --- | --- |
| 500 CAPTION strict: 2.46→0.70%, F1 0.812 | `large_strict_500_metrics.json` | ✅ |
| 500 DETAILED strict: 6.07→2.99%, F1 0.610 | `large_strict_detailed_500_metrics.json` | ✅ |
| POPE 91.34/90.83/89.97% | `pope/pope_metrics.json` | ✅ |
| Cross200 self vs cross: 2.41→1.05 / 4.70→2.07 | `cross_self_metrics.json` / `cross_blip_metrics.json` | ✅ |
| 500 ablation aggressive: 4.48→1.46% | `large_aggressive_500_metrics.json` | ✅ |

## 2. 통계적 유의성 점검

- **500 CAPTION strict**: baseline [1.50, 3.55] ⊥ verified [0.14, 1.39] → 유의 (겹침 0).
- **500 DETAILED strict**: baseline [4.73, 7.40] ⊥ verified [2.05, 4.01] → 유의.
- **POPE recall = 0.8365 (정확히 동일 3 split)**: 같은 OD 출력 + 같은 yes-question 집합 때문. 정상.
- **Cross200 self vs cross F1 동률 (0.7273)**: TP/FN 비율이 같음 (4/3 ≈ 8/6). 우연 아니라 OD recall 한계 때문 — 논문 5.4 절에서 명시.

## 3. FP/FN 패턴 분석 (Phase 2.2 self-review 연장)

### 500 CAPTION strict FP (=1)
- `186632 sink`: 욕실, sink 작음 → OD miss. → 작은 객체 recall 한계.

### 500 DETAILED strict FP (=14)
- bowl(3), spoon(2), bottle(2), couch(2), bird/sink/person/bench/car(각 1).
- 식기류·욕실 객체 집중 → OD가 작은 객체 못 잡음.

### 결론
모든 FP는 **synonym 매핑 오류가 아니라 OD recall 한계**. strict vocab으로 매핑 오류는 제거됐고, 남은 FP는 진짜 모델 한계. 논문 6.2 Limitations 절에서 이 점을 정확히 보고함.

## 4. 코드/저장소 상태

### 4.1 GitHub에 올라간 코드
- 모든 파이프라인 스크립트 (`code/florence2/`, `code/modules/`, `code/run_*.py`)
- 환경 파일 (`code/env/requirements.txt`, `environment.yml`)
- README.md (프로젝트 설명 — Claude 언급 없음)
- 논문 초안 (`paper/draft_ko.md`)

### 4.2 gitignore된 로컬-only
- `CLAUDE.md` (Team/ 상위)
- `progress/STEP1~11_*.md` (작업 일지)
- `data/` (이미지·어노테이션)
- `outputs/` (결과 CSV/JSON/이미지)

### 4.3 Repo 깔끔도 점검
- 모든 코드 PEP8 호환, docstring 있음
- 타입 힌트 일관성 있음
- 함수 시그니처 안정 (vocab 인자 default `strict`)
- `relative_to` 크래시 같은 발견된 버그 모두 수정 (커밋 `bdbafe9`)

## 5. 논문 점검 (paper/draft_ko.md)

### 5.1 좋은 점
- 7장 + 요약 + 참고문헌 구조, IPIU2026 4~6쪽 범위 적합
- 모든 수치에 95% CI 동반
- 외부 비교 (POPE 5개 baseline) 명시
- ablation 표 (vocab)
- 정성 figure 가이드 (그림 2~4 출처 image_id 명시)
- 한계와 향후 방향 분리

### 5.2 향후 사용자가 직접 해야 할 작업
1. IPIU2026 .doc 양식에 본문 옮겨담기 (글꼴/장 번호 적용)
2. **그림 1**: pipeline overview 직접 작성 (PowerPoint / Inkscape)
3. **그림 2~4**: `outputs/qualitative_500/`, `outputs/qualitative_large/` 에서 image_id 5503, 64084, 78426 선택해 옮기기
4. 저자/소속/이메일 입력 (발표자 위 `o`)
5. 감사의 글 보강
6. 표 1~5 .doc 표 스타일로 옮기기

### 5.3 잠재적 reviewer 질문 대응
| 질문 | 본 논문에서 답변 위치 |
| --- | --- |
| Self-verification은 왜 일부만 잡는가? | 5.4 Cross-model + 6.2 Limitations |
| Hallucination rate가 너무 작은데? | 5.3 POPE 외부 평가 — LVLM 대비 우수성 |
| Synonym 매핑이 임의적이지 않나? | 5.5 Ablation 표 + 3.2 절 정의 |
| 500장은 표본이 작지 않나? | 95% bootstrap CI 일관성 (모든 표) + POPE 1500 yes-question |
| 대형 모델 (LLaVA 등) 과 직접 caption 비교했나? | 5.4 Cross-model (BLIP) — 직접 비교 / 큰 모델은 향후 |

## 6. 발견된 보완 사항 (남는 작은 일들)

| 사항 | 우선순위 | 위치 |
| --- | --- | --- |
| 그림 1 (pipeline overview) 자동 생성 스크립트 | 낮음 | `paper/figures/` 비어 있음 |
| FP 카테고리별 분포 정성 표 추가 | 낮음 | 본 보고서 §3 |
| Aggressive vocab 추가 mention 50건의 카테고리 분포 | 낮음 | `outputs/captions/large_aggressive_extracted_500.csv` |
| `<CAPTION_TO_PHRASE_GROUNDING>` 전략 비교 표 (이미 코드 있음) | 중 | 5.4 cross 와 비슷한 분량으로 추가 가능 |

이들은 워크샵 통과 수준에는 필수 아님 — 학술지/conference 격상 시 보강 후보.

## 7. 변경된 저장소 상태 — Pass 2 전체
- `d03f683` Phase 1: strict synonym vocab
- `1ae397f` Bootstrap CIs + POPE evaluator + extract_only
- `698b1a4` Phase 4 scaffolding: BLIP-2 + cross orchestrator
- `7fcfdde` Bootstrap CIs in step4 + run_compare_all
- `eb78b88` Phase 4 BLIP-large fallback + Phase 5 ablation runner
- (다음) Phase 6 paper rewrite + final progress logs

## 8. 결론

**Pass 2 종료.** 모든 phase가 완료되었고 결과는 일관·정직·통계적으로 유의함. 사용자 잔여 작업은 양식 변환·figure 제작 5종 가량으로 한정.
