# Step 1 — 환경 세팅 + Florence-2 Smoke Test

> **목표**: 가상환경 만들고 Florence-2-base-ft를 한 번이라도 실제로 실행해서 `<CAPTION>` / `<DETAILED_CAPTION>` / `<OD>` 출력 형태를 확정한다.

## 1. 환경 (Windows native PowerShell)

WSL 대신 **PowerShell + venv** 채택 이유:
- RTX 3070 CUDA 드라이버가 이미 잡혀 있어 추가 설정 불필요
- 리포가 `C:\` 경로라서 WSL `/mnt/c/` I/O 페널티 회피
- 시스템 Python 3.11 재사용 가능

### 명령 (사용자가 실행)
```powershell
cd c:\Users\jinyo\jeeen0\ComputerVision\Team\florence2-hallucination-detection
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu121
pip install transformers accelerate timm einops pillow opencv-python matplotlib pandas pycocotools pyyaml tqdm
```

### 설치 검증 결과
```
torch        2.5.1+cu121
cuda         True
device       NVIDIA GeForce RTX 3070
transformers 5.9.0  ← 처음엔 이 버전이 설치됨 (호환성 문제 발생)
```

## 2. 막힌 지점 — Florence-2 vs transformers 5.x 비호환

첫 실행 시:
```
AttributeError: 'Florence2LanguageConfig' object has no attribute 'forced_bos_token_id'
```

### 원인
Florence-2는 HF에서 가중치를 받을 때 `trust_remote_code=True` 로 모델/processor의 *커스텀 Python 모듈*을 함께 받아 실행합니다. 이 커스텀 모듈은 transformers 4.x 시절 API에 의존하는데, transformers 5.x에서 `PretrainedConfig.__getattribute__` 로직이 바뀌어 미초기화 속성 접근 시 더 이상 None을 돌려주지 않고 예외를 던집니다.

구체적으로 `configuration_florence2.py:265` 의 다음 라인이 깨집니다:
```python
if self.forced_bos_token_id is None and kwargs.get("force_bos_token_to_be_generated", False):
```

### 해결
`transformers==4.49.0` 로 다운그레이드 (4.x 중 Florence-2 패치가 들어간 마지막 라인).
```powershell
pip install "transformers==4.49.0"
```

→ `code/env/requirements.txt` 와 `code/env/environment.yml` 에 **버전 핀 + 주석으로 이유 기록** (재발 방지). 커밋됨.

> **교훈**: trust_remote_code 모델은 transformers 메이저 버전 업그레이드에 무방비. 반드시 핀.

## 3. 테스트 이미지

COCO val2017에서 한 장 받아옴:
```
curl -L -o data/coco_val/000000000139.jpg \
  http://images.cocodataset.org/val2017/000000000139.jpg
```
파일 크기: 162 KB. (`data/` 폴더는 `.gitignore` 처리되어 있어 GitHub에 안 올라감.)

## 4. Smoke test 명령
```powershell
python code/run_sample.py --image data/coco_val/000000000139.jpg
```

## 5. 결과

### `<CAPTION>`
> A woman standing in a kitchen next to a table.

### `<DETAILED_CAPTION>`
> In this picture we can see a woman standing on the floor and in front of her there is a table, on the table there are some flower vases, in the background we can find a television, cupboards, windows, lights, refrigerator and a woman sitting on the chair.

### `<OD>`
총 **19개** detection. 라벨 예시: `chair`, `clock`, `dining table`, `person`, ...

CSV 일부:
```
image_id,label,x1,y1,x2,y2
sample,chair,361.28,220.03,416.32,318.44
sample,chair,294.08,217.90,350.40,317.16
sample,chair,410.56,220.46,440.00,303.52
sample,clock,448.32,120.77,460.48,141.65
sample,dining table,320.96,230.68,445.76,318.44
sample,person,409.92,157.83,463.68,295.86
sample,person,384.32,173.17,399.68,206.40
...
```

### 저장된 파일
| 파일 | 설명 |
| --- | --- |
| `outputs/captions/sample_caption.csv` | `<CAPTION>`, `<DETAILED_CAPTION>` 두 행 |
| `outputs/captions/sample_od.csv` | 검출 1개당 1행, COCO80 클래스 + bbox |
| `outputs/captions/sample_raw.json` | 위 셋의 raw + 이미지 경로·모델 ID |
| `outputs/visualizations/sample_od.jpg` | bbox + 라벨 overlay (90 KB) |

## 6. Step 1에서 확정된 사실 (Step 2+ 설계 입력)

1. **OD 출력 형식**: `{'<OD>': {'bboxes': [[x1,y1,x2,y2], ...], 'labels': [str, ...]}}`. score는 없음 → 평가지표에서 score 기반 NMS/threshold 가정 불가.
2. **라벨 어휘**: COCO80 거의 그대로 (`person`, `chair`, `dining table`, `clock` 등 확인). 단, 표기는 일부 다를 수 있음 (`tv` vs `television`) → synonym 매핑 테이블 Step 2에서 본격적으로 정리.
3. **Caption 어휘**: 명사·복수형·관사 섞임. Mention 추출 시 lemmatization 필요.
4. **DETAILED_CAPTION**은 한 문장에 다수 객체 나열 — Step 2의 mention 추출 알고리즘이 이 문장도 잘 다뤄야 함.
5. **속도**: 첫 실행은 모델 가중치 다운로드 포함해서 약 2분, 두 번째부터는 5초 내외 (RTX 3070).

## 7. 변경된 저장소 상태

- 커밋 `2448be4` Step 1: Florence-2 wrapper and sample runner for <CAPTION>/<OD>
- (이번에 커밋 예정) requirements에 `transformers==4.49.0` 핀, `progress/` gitignore 추가

## 8. 다음 (Step 2 예고)

1. COCO val2017 일부 이미지 + `instances_val2017.json` 다운로드
2. `code/modules/extract.py` — caption → COCO80 어휘 기반 object mention 추출 + synonym 매핑
3. 50장 대상으로 `<CAPTION>` 생성 후 mention 추출 결과 CSV 저장
4. 산출물: `outputs/captions/base_caption_50.csv`, `outputs/captions/base_extracted_objects.csv`
