# Step 12 — Option C 확장 실험 (1000장 + multi-seed + cross500 + phrase-grounding)

> **목표**: 외부 비평·self-critique 에서 지적된 표본 부족 + recall 동률 우연 가능성 + phrase grounding 미보고 등을 정면 반박할 수 있는 보강 실험을 모두 수행한다.

## 1. 실행 작업

| # | 작업 | n | 비고 |
| --- | --- | --- | --- |
| C-1 | 메인 1000장 (seed 7, strict, CAPTION) | 1000 → 1433 mentions | 표본 두 배 |
| C-2 | Cross-model 200 → 500 | 500 → self 732 mentions, cross 739 | self vs cross 표본 강화 |
| C-3 | Multi-seed × 500 (seeds 42, 123) | 각 500 | seed 7 외 2 시드 추가 |
| C-4 | `<CAPTION_TO_PHRASE_GROUNDING>` ablation | 500 | 검증 전략 비교 |

## 2. 핵심 결과

### 2.1 1000장 본 실험 (C-1)
| | 500 (seed=7) | **1000 (seed=7)** |
| --- | ---: | ---: |
| Mentions | 732 | **1433** |
| Baseline Hall% | 2.46 [1.50, 3.55] | **2.30 [1.54, 3.07]** |
| Verified Hall% | 0.70 [0.14, 1.39] | **0.78 [0.36, 1.28]** |
| Precision | 0.929 | **0.710** |
| Recall | 0.722 | **0.667** |
| **F1** | 0.812 [0.636, 0.941] | **0.688 [0.526, 0.805]** |
| Grd Acc@0.5 | 95.65% | **95.69%** |

**관찰**: 1000장에서 F1 이 0.81 → 0.69 로 떨어짐. 500장의 F1=0.81 은 *FP=1* 인 운 좋은 표본이었음. 1000장에서 FP=9 로 늘면서 precision 가 0.71 로 안정화. **더 큰 표본이 더 정직한 추정치**.

### 2.2 Multi-seed 안정성 (C-3)
500장 × 3 seeds:

| Seed | Mentions | Baseline (%) | Verified (%) | P | R | F1 |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 7 | 732 | 2.46 | 0.70 | 0.929 | 0.722 | 0.812 |
| 42 | 689 | 3.34 | 1.04 | 0.842 | 0.696 | 0.762 |
| 123 | 724 | 3.31 | 0.85 | 0.818 | 0.750 | 0.783 |
| **mean** | **715** | **3.04** | **0.86** | **0.863** | **0.723** | **0.786** |

**관찰**: 500장 규모에서 F1 0.76~0.81 범위 (변동 ±0.025). 시드 7 의 F1=0.81 은 약간 high-end. 합리적 추정치는 mean F1 ≈ 0.79. 1000장 F1=0.69 는 표본 두 배에서의 안정화 결과.

### 2.3 Cross-model 500장 (C-2)
| Setting | Mentions | Baseline | Verified | P | R | F1 | TP / FN |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| Self (F2 cap + F2 OD) | 732 | 2.46 | 0.70 | 0.929 | 0.722 | 0.812 | 13/5 |
| **Cross (BLIP cap + F2 OD)** | 739 | **4.74** | 1.54 | 0.889 | **0.686** | **0.774** | 24/11 |

**관찰**:
- BLIP-large 가 Florence-2 보다 ~2× 자주 hallucinate (4.74 vs 2.46).
- 두 설정 모두 검증 recall 이 0.69~0.72 — *200장에서의 "정확히 0.571 동률" 은 작은 표본 우연이었음* 을 정정.
- 그러나 두 recall 이 비슷한 범위에 머문다는 점은 *captioner 변경으로 검증 민감도가 크게 개선되지 않음* 을 시사. **OD recall 이 주요 병목** 메시지는 유지.

### 2.4 검증 전략 ablation (C-4)
| Strategy | Mentions | unsupported | F1 |
| --- | ---: | ---: | ---: |
| `<OD>` (main) | 732 | **14** | **0.812** |
| `<CAPTION_TO_PHRASE_GROUNDING>` | 732 | **0** | **0.000** |

**놀라운 관찰**: phrase grounding 은 거의 모든 mention 에 적어도 하나의 bbox 를 반환 → unsupported = 0 → 검증 신호 없음.

**의미**: 페이퍼에서 `<OD>` 를 채택한 이유가 *cost* 뿐 아니라 *유효성* 차원에서도 명확해졌다. phrase grounding 은 hallucination 검출 도구로 부적합.

## 3. 외부 비평 대응 결과

| 비평 항목 | C 실험 결과로 정정 |
| --- | --- |
| "표본 부족, F1 CI 너무 넓음" | 1000장 추가 → F1 CI [0.526, 0.805] 로 좁힘. 추가로 multi-seed (3개) 결과 평균 보고 |
| "cross 200 의 동률 0.571 우연 가능" | 500장 cross 결과 → 두 recall 비슷한 범위지만 정확 동률은 아님을 정정 |
| "`<OD>` 결과 차이 미미 근거 없음" | 명시적 ablation 표로 phrase grounding 의 무력함 직접 보여줌 (F1=0) |
| "Florence-2 OD 가 LVLM 능가" 단정 | "OD-based baseline 으로 reported 값보다 높음, task 다르므로 직접 비교 X" 로 톤다운 |
| "이전 문헌 효과 사라짐" 단정 | "어휘 정책에 따라 과대평가될 수 있음" 으로 톤다운 |

## 4. 페이퍼 업데이트 내용

- **표 1**: 1000장 결과로 교체. baseline 2.30 → verified 0.78, F1 0.688.
- **표 1b**: removal 분석 1000장 수치로 갱신 (retention 97.8%).
- **표 1c**: multi-seed 500장 × 3 안정성 표 신설.
- **표 4**: cross 500장 결과로 교체.
- **표 5**: vocab + prompt + verification strategy 3-way ablation.
- **§5.5**: `<CAPTION_TO_PHRASE_GROUNDING>` ablation 결과 + "OD가 일관되게 더 적합한 verification primitive" 결론.

## 5. 솔직 평가

본 보강 실험 후 페이퍼 상태:

- **표본 크기 비판**: 해결. 1000장 메인 + 3 seed 안정성으로 충분.
- **F1 안정성**: 0.69~0.81 범위 보고. 평균 0.79, 1000장 보수적 추정치 0.69.
- **Cross-model 결론**: "OD recall 이 주요 병목" 메시지는 살아남음 — 표본을 늘려도 self/cross 둘 다 recall ~0.7 범위.
- **검증 전략**: `<OD>` 채택 정당화 완료 (phrase grounding 무효).

워크샵 (IPIU2026) 수준에서 **거의 모든 reviewer 질문에 답할 수 있는 상태**. 4090에서 추가 작업하면 더 좋아질 수 있지만 현재 상태로도 제출 충분.

## 6. 산출물 (모두 outputs/ 내부, gitignore)
- `outputs/captions/large_strict_caption_1000.csv`, `large_strict_caption_seed{42,123}.csv`
- `outputs/grounding/large_strict_1000_grounding.csv`, `..._seed{42,123}_grounding.csv`, `..._500_grounding_phrase.csv`
- `outputs/cross/{self,cross}_grounding_500.csv`, `blip2_caption_500.csv`
- `outputs/metrics/*_metrics.json` 15개
- `outputs/metrics/all_compare.md` 갱신된 통합 표 (15 rows)

## 7. 변경된 저장소 상태
- 커밋 `79073a6` Paper update with 1000-img + multi-seed + cross-500 + phrase grounding ablation
