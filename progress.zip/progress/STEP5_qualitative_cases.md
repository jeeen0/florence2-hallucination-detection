# Step 5 — 정성 분석: 성공·실패 사례 자동 선별

> **목표**: Step 3 결과 + COCO GT를 결합해 TP / FN / FP 케이스를 자동 분류하고, 논문 정성 결과 섹션에 그대로 들어갈 시각화 + 메타데이터를 생성.

## 1. 추가된 코드

| 파일 | 역할 |
| --- | --- |
| `code/run_step5.py` | grounding CSV × GT → (TP/FN/FP/TN) 분류 → 해당 케이스의 Step 3 viz 복사 + `cases.md` |

## 2. 분류 규칙

| 시스템 예측 | GT 존재 | 태그 | 의미 |
| --- | --- | --- | --- |
| unsupported | 없음 | **TP** | 자기검증이 hallucination을 올바르게 잡음 |
| supported | 없음 | **FN** | caption AND OD가 동시에 hallucinate (joint failure) |
| unsupported | 있음 | **FP** | 실제 객체를 잘못 기각 |
| supported | 있음 | TN | 정상 |

## 3. 실행
```powershell
python code/run_step5.py
```

## 4. 결과 (Florence-2-base-ft, 50 images)
- **TP = 4**
- **FN = 2**
- **FP = 0**
- TN = 67

### TP (성공 사례 — 모두 보고서에 포함 가능)
| image | mention | caption | GT |
| --- | --- | --- | --- |
| `2153` | `sports ball` (`baseball`) | "A baseball player holding a bat on top of a field." | `baseball bat`, `person` |
| `6012` | `bowl` | "A bunch of bananas and an apple in a bowl." | `banana` |
| `6471` | `sports ball` (`baseball`) | "A baseball player holding a bat on a field." | `baseball bat`, `baseball glove`, `bench`, `bottle`, `person` |
| `10764` | `sports ball` (`baseball`) | "A baseball player squatting down to catch a ball." | `baseball glove`, `person` |

→ 야구 장면 3건 모두 *공*이 GT에 없음 (`baseball bat` / `baseball glove`만). 시스템이 공이 시각적 근거가 없음을 정확히 식별.

### FN (실패 사례 — Limitation 절 핵심 증거)
| image | mention | caption | GT |
| --- | --- | --- | --- |
| `5503` | `person` | "A person standing in front of a toilet with the seat up." | `toilet` |
| `6012` | `apple` | "A bunch of bananas and an apple in a bowl." | `banana` |

→ 둘 다 caption이 거짓 객체를 말하고 OD도 동일하게 거짓 객체를 검출 (joint hallucination). **동일 모델 self-verification의 본질적 한계**. 보고서 *Limitation* 절에서 이 두 케이스를 그대로 인용.

### FP (없음)
한 건도 없음 → 시스템이 매우 보수적. Precision = 1.0의 정성적 근거.

## 5. 산출물
```
outputs/qualitative/
├── cases.md                          ← 위 표를 포함한 마크다운 요약
├── success/                          ← TP 4건 시각화 jpg
│   ├── 000000002153_TP_sports_ball.jpg
│   ├── 000000006012_TP_bowl.jpg
│   ├── 000000006471_TP_sports_ball.jpg
│   └── 000000010764_TP_sports_ball.jpg
├── failure_FN/                       ← FN 2건 시각화 jpg
│   ├── 000000005503_FN_person.jpg
│   └── 000000006012_FN_apple.jpg
└── failure_FP/                       ← (없음)
```

## 6. 보고서 활용 계획

- **본문 Figure 1**: pipeline overview (별도 작성).
- **본문 Figure 2**: TP `6012` (bowl/banana/apple 케이스) — caption의 `bowl`을 시스템이 unsupported로 깃발 듦. 동시에 `apple`은 FN으로 놓침 → 같은 이미지에서 한 사례가 success와 failure를 동시에 보여줘 effective.
- **본문 Figure 3**: TP `2153` 또는 `6471` (baseball 케이스) — caption은 "공"을 말하지만 실제로는 *bat*만. 시스템 강점.
- **Limitation 도식**: FN `5503` (toilet 앞 person) — 사람이 없는데 caption + OD 둘 다 "person"이라 함.

## 7. 변경된 저장소 상태
- 커밋 `fd515f7` Step 5: qualitative case selection (TP/FN/FP) with markdown summary
