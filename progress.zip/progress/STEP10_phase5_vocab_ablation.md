# Step 10 (Phase 5) — Synonym Vocab Ablation (strict vs aggressive on 500 imgs)

> **목표**: synonym 어휘 정책이 hallucination 지표에 미치는 영향을 같은 500장에서 측정하여, Phase 1에서 직관적으로 결정한 *strict ≪ aggressive* 인플레이션 효과를 정량 보고한다.

## 1. 설계

같은 500 images, 같은 캡션 (`large_strict_caption_500.csv`), 같은 OD 호출. 차이는 **mention 추출 / OD label 정규화**에 쓰이는 synonym vocab 만.

`code/run_ablation_vocab.py` 가 다음을 한 번에 실행:
1. `extract_only.py --vocab aggressive` : 캡션 재사용 + mention 재추출 (모델 호출 0)
2. `run_step3.py --vocab aggressive` : OD 재호출 + aggressive 정규화
3. `run_step4.py` : metric (bootstrap CI 포함)
4. `run_compare_all.py` : 전체 표 갱신

## 2. 결과

| Vocab | n_mention | Baseline (95%CI) | Verified (95%CI) | P | R | F1 (95%CI) | GrdAcc@0.5 |
| --- | --: | --: | --: | --: | --: | --: | --: |
| **strict** | 732 | **2.46% [1.50, 3.55]** | **0.70% [0.14, 1.39]** | 0.93 | 0.72 | **0.812 [0.636, 0.941]** | 95.65% |
| **aggressive** | **782** | **4.48% [3.07, 6.04]** | 1.46% [0.69, 2.34] | 0.92 | 0.69 | 0.787 [0.677, 0.882] | 95.30% |

(같은 500 캡션·같은 모델·다른 vocab만)

### 2.1 mention 수 차이 50건
aggressive가 50 mention 더 잡음 → 주로 `table/tables → dining table`, `baseball → sports ball`, `monitor → tv`, `plant/plants → potted plant`, `stove/stoves → oven`, `glove/gloves → baseball glove`.

### 2.2 Baseline 인플레이션 +80%
- strict 2.46% → aggressive 4.48%. 거의 두 배.
- 추가 mention 50건 중 *대부분이 GT에 없음* (예: caption의 `table`이 GT에선 dining table이 아니거나, `baseball`이 sport context인데 GT에 sports ball 없음).
- **이는 hallucination이 아니라 어휘 매핑 결과**. Phase 1 분석과 일치.

### 2.3 F1은 거의 같음 (0.812 vs 0.787)
- 어휘 인플레이션이 baseline rate를 부풀리지만, 검증 시스템이 같은 비율로 잡아냄.
- 따라서 *상대적인 검증 효과* (verification이 hallucination을 얼마나 줄이는지) 는 vocab 선택에 robust.
- 단 *절대 rate* 보고는 vocab에 매우 민감 → 정직한 보고는 vocab 명시 + ablation 표.

### 2.4 95% CI 비교
- strict baseline [1.50, 3.55] vs aggressive [3.07, 6.04] → CI 겹침 영역 있음 ([3.07, 3.55])
  - 즉 두 baseline은 같다고 단정 못 함, 그러나 점추정으로는 분명히 다름
- F1 [0.636, 0.941] vs [0.677, 0.882] → 완전 겹침 → F1은 vocab에 robust

## 3. 페이퍼 활용

논문 *Ablation* 절에 표 1 (vocab × {base, verified, F1}) 로 보고:

| Vocab | Mentions | Baseline (%) | Verified (%) | F1 |
| --- | --: | --: | --: | --: |
| strict (ours, conservative) | 732 | 2.46 | 0.70 | 0.81 |
| aggressive (legacy) | 782 | 4.48 | 1.46 | 0.79 |

본문 메시지:
> "Prior reports of self-verification gains on COCO can be inflated by over-aggressive synonym mappings. We re-run with a strict mapping that removes generic-to-specific entries (e.g., *table → dining table*); baseline halves but F1 is preserved."

## 4. 발견된 이슈 / 보완 사항
1. 본 ablation은 *vocab만* 비교 — prompt(CAPTION vs DETAILED), 모델 크기(base vs large)는 다른 결과 표에 분산. 종합 ablation 표는 Phase 6에서 작성.
2. mention 수 차이 50건의 *카테고리별 분포* 는 아직 분석 안 함 (보완 가능).
3. aggressive vocab 결과는 *과거 보고된 8.22% / 3.77%*와 직접 비교 가능 — 이전 base/large 100-img 실험과 같은 어휘 정책.

## 5. 산출물
| 파일 | 내용 |
| --- | --- |
| `outputs/captions/large_aggressive_caption_500.csv` | 같은 caption, aggressive mention 추출 |
| `outputs/captions/large_aggressive_extracted_500.csv` | mention 1행/건 |
| `outputs/grounding/large_aggressive_500_grounding.csv` | OD 검증 결과 |
| `outputs/metrics/large_aggressive_500_metrics.json` | bootstrap CI 포함 메트릭 |
| `outputs/metrics/all_compare.md` | 통합 비교 표 (9 rows) |

## 6. 변경된 저장소 상태
- 커밋 `eb78b88` Phase 4 BLIP-large fallback + Phase 5 ablation runner
- (다음) Phase 5 ablation 진행 로그 + Phase 6 paper rewrite

## 7. 다음 (Phase 6 — paper rewrite)
새 데이터로 `paper/draft_ko.md` 전체 재작성:
1. Result 표를 9-row 비교로 교체 (strict 500 CAPTION 메인, DETAILED 보조, aggressive ablation, POPE)
2. Section 5 결과에 POPE 비교 추가
3. Section 5에 self vs cross 비교 추가
4. Section 6 Discussion에서 self-verification 한계 *원인 분리* (OD recall vs joint blind spot)
5. Section 4 Method에 strict synonym vocab 정책 명시
6. Section 6.2 Limitations 갱신 (small object detection limitation 포함)
