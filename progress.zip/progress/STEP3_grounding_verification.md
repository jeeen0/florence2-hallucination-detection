# Step 3 — Grounding / Detection 기반 검증

> **목표**: Step 2의 mention 들을 Florence-2 `<OD>` 결과와 매칭하여 supported / unsupported 분류 + bbox 시각화.

## 1. 추가된 코드

| 파일 | 역할 |
| --- | --- |
| `code/modules/verify.py` | `<OD>` 호출 + canonical 라벨 매칭 + supported/unsupported 판정. `<CAPTION_TO_PHRASE_GROUNDING>` 대안도 포함 |
| `code/modules/visualize.py` | green=supported / red=unsupported overlay |
| `code/run_step3.py` | Step 3 오케스트레이터 |

## 2. 검증 전략

**기본**: 이미지 1장당 `<OD>` 1회 호출 → 검출된 모든 (bbox, label)에 대해 `_LABEL_TO_CANONICAL[label]`로 COCO80 canonical 추출 → 각 caption mention의 canonical과 매칭.

**대안** (`--strategy grounding`): mention 1개당 `<CAPTION_TO_PHRASE_GROUNDING>` 1회 호출. 더 정확할 수 있지만 비용 N배.

→ Step 3은 `od` 전략으로 진행.

## 3. 판정 규칙

```
mention.canonical 이 OD 검출의 어떤 detection.canonical 과 일치하면:
    supported = True
    bbox      = 첫 매칭 검출의 bbox
그 외:
    supported = False
    bbox      = None
```

## 4. 실행

```powershell
python code/run_step3.py
```

각 이미지에 대해 `<OD>` 1회 호출 → 50장 약 4~5분.

## 5. 결과

| 지표 | 값 |
| --- | --: |
| Total mentions | 73 |
| Supported | 69 (94.5%) |
| Unsupported | 4 (5.5%) |

### Unsupported 4건의 분포
| image_id | mention surface | canonical |
| ---: | --- | --- |
| 2153 | baseball | sports ball |
| 6471 | baseball | sports ball |
| 10764 | baseball | sports ball |
| 6012 | bowl | bowl |

**관찰**:
- 3/4가 "baseball" → Florence-2 `<OD>`는 *baseball* / *sports ball* 라벨로 검출하지 않은 듯. caption은 `"baseball player ..."` 같은 식으로 부르지만 OD는 `person` + `baseball bat` 위주로 검출.
- 1건은 "bowl" — 이미지 자체에 bowl이 작거나 occluded일 가능성. Step 4 GT 매칭에서 어떻게 처리되는지 확인 가능.

### 출력 파일
| 파일 | 내용 |
| --- | --- |
| `outputs/grounding/base_grounding_results.csv` | mention 1개당 1행 (status, bbox) |
| `outputs/visualizations/base/<image_id>_verified.jpg` | 검증 결과 overlay 이미지 50장 |

## 6. 시각화 디자인

- **녹색 bbox + 라벨**: supported mention의 매칭 bbox.
- **상단 좌측 텍스트 오버레이**:
  - `caption: <원문>`
  - `supported: <리스트>`
  - `unsupported: <리스트>` (있을 때만 빨강)
- 모든 텍스트는 검정 stroke로 outline → 배경과 무관하게 가독성 확보.

## 7. 알게 된 점 (Step 4 입력)

1. `_LABEL_TO_CANONICAL` 의 keys는 `extract.py`와 100% 공유 → OD 라벨이 synonym map에 없으면 무조건 unsupported가 됨. Florence-2 OD가 사용하는 라벨 집합이 정확히 COCO80에 정렬되는지 추가 검증 필요.
2. caption은 "baseball" 같은 종목 이름을 쓰지만 OD는 종목 이름으로 라벨링하지 않음 → "sports ball" 매핑이 캐치 못함. Step 4에서 GT 비교 후 보정 전략 고려.
3. supported/unsupported 분류는 OD의 recall 한계에 영향 받음 — OD가 못 잡으면 무조건 unsupported. → 동일-모델 self-verification의 본질적 한계 (보고서 *Limitation*에 반드시 명시).

## 8. 변경된 저장소 상태
- 커밋 `4d0e666` Step 3: <OD>-based caption-grounding verification + visualization
